# DoFactorydotNetDesignPattern
http://www.dofactory.com/net/design-patterns

# Under-construction :warning:
