﻿namespace DoFactory.GangOfFour.Visitor.RealWorld
{
    class President : Employee
    {
        // Constructor
        public President()
          : base("Dick", 45000.0, 21)
        {
        }
    }
}
